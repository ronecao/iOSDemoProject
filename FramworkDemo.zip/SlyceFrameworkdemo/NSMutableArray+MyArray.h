//
//  MyArray.h
//  SlyceFrameworkdemo
//
//  Created by Chris on 13/03/2018.
//  Copyright © 2018 chris. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface  NSMutableArray(MyArray)
@property (nonatomic,retain) NSString * mName;




@end
