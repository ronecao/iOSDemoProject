//
//  MyArray.m
//  SlyceFrameworkdemo
//
//  Created by Chris on 13/03/2018.
//  Copyright © 2018 chris. All rights reserved.
//

#import "NSMutableArray+MyArray.h"

@implementation NSMutableArray(MyArray)
@synthesize mName;

@end
